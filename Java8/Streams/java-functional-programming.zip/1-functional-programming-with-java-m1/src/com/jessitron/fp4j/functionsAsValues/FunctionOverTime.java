package com.jessitron.fp4j.functionsAsValues;

@FunctionalInterface
public interface FunctionOverTime {

    double valueAt(int time);

}
