package com.jessitron.fp4j6;

public interface QuantityOfInterest {

    String getName();

    double valueAt(final int time);

}
