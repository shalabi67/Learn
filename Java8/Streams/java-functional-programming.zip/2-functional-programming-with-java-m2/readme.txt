Prereq:
You'll need to set up your 1.6 and 1.8 SDKs if you haven't yet.

Examples:

the central module (with the same name as the project) contains the java 8 versions. There are several packages with different code.
"timing" is the first example, and then
"i_..." through "vi_..." (roman numerals) contain different versions of the
timing example, following along through the improvements in the video.

"collections" contains the second example.

The java7 module contains "timing" and "collections" compatible with Java 6 or later.
