Requirements:
* Java SDK version 8 or higher (for most examples)
* Java SDK version 7 or lower (for pre-Java-8 examples)

Recommended:
IntelliJ IDEA community edition
