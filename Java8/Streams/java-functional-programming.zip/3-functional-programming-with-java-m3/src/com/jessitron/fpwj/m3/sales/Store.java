package com.jessitron.fpwj.m3.sales;

public enum Store {
  KANSAS_CITY,
  CHICAGO,
  ST_LOUIS
}
