package threadpools.monteCarlo.threadPool;

public class PIResult
{
	private int result;
	
	public void setResult(int result)
	{
		this.result = result;
	}
	
	public int getResult()
	{
		return result;
	}
}
