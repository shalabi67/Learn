package sharingMemory.producerConsumer.nowSynchronized;

public interface ProduceObserver {
	void onProduction(Produce produce);
}
