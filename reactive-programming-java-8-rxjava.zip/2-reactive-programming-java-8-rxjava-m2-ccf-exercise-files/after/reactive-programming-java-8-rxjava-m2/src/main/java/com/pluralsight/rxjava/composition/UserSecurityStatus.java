package com.pluralsight.rxjava.composition;

public enum UserSecurityStatus {

    GUEST,
    USER,
    MODERATOR,
    ADMINISTRATOR
}
