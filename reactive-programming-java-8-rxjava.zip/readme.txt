Reactive Programming in Java 8 with RxJava

To compile and execute the demonstration code for this course, the following software is required:

* Java 8
	This course uses lambda expressions and closures heavily.  Java 8 is required.

* Gradle 1.10 or higher
	All example code comes with a Gradle build file.

* Netbeans 7.4 or greater.
	Any Gradle compatible IDE should work just fine.  Netbeans 7.4 was used in the creation of all demonstration videos.

	