package com.pluralsight.rxjava.dataaccess.shared;

public enum UserSecurityLevel {
    LEVEL_GUEST,
    LEVEL_MEMBER,
    LEVEL_MODERATOR,
    LEVEL_ADMIN
}
